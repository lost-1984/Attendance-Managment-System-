<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../home/index.php');
    exit();
}

include('../includes/db_connect.php');

$admin_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param('i', $admin_id);
$stmt->execute();
$stmt->bind_result($admin_username);
$stmt->fetch();
$stmt->close();

$stmt = $conn->prepare("
    SELECT c.course_name, u.username AS teacher_name
    FROM courses c
    JOIN users u ON c.teacher_id = u.id
");
$stmt->execute();
$courses_result = $stmt->get_result();
$courses = $courses_result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <title>Admin Dashboard</title>
    <style>
        .greeting {
            font-size: 20px;
            font-weight: bold;
            text-align: left;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="greeting">
            Hi, <?php echo htmlspecialchars($admin_username); ?>
        </div>
        <h1>Welcome Admin</h1>
        <a href="manage_users.php">Manage Users</a>
        <a href="mark_attendance.php">Mark Attendance</a>
        <a href="view_update attendance.php">View/Update Attendance</a>
        <a href="check_attendance.php">Students Attendance Record</a>
        <a href="add_course.php">Add New Course</a>
        <a href="courses_by_teacher.php">Courses We Offer</a>
        <a href="create_account.php">Create Account</a>
        <a href="../includes/logout.php">Logout</a>
    </div>
    <script src="../assets/js/admin.js"></script>
</body>
</html>
