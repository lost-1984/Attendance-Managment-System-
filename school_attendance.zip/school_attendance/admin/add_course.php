<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'admin') {
    header('Location: ../home/index.php');
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$stmt = $conn->query("SELECT id, username FROM users WHERE role = 'teacher'");
$teachers = $stmt->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $course_name = htmlspecialchars($_POST['course_name']);
        $teacher_id = (int)$_POST['teacher_id'];

        $check_stmt = $conn->prepare("SELECT id FROM courses WHERE course_name = ?");
        $check_stmt->bind_param('s', $course_name);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();

        if ($check_result->num_rows > 0) {
            $error_message = "Course '$course_name' already exists in the database. Please choose a different name.";
        } else {
            $insert_stmt = $conn->prepare("INSERT INTO courses (course_name, teacher_id) VALUES (?, ?)");
            $insert_stmt->bind_param('si', $course_name, $teacher_id);
            $insert_stmt->execute();
            $insert_stmt->close();

            $success_message = "Course '$course_name' added successfully.";

            // Redirect to the admin dashboard or a success page
            // header('Location: dashboard.php');
            // exit();
        }
    } else {
        $error_message = "Invalid CSRF token.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="admin1.css">
    <style>
        .error-message{
            color: red;
        }
        .success-message{
            color: green;
        }
    </style>
    <title>Add New Course</title>
</head>
<body>
    <div class="container">
        <h1>Add New Course</h1>
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php elseif (!empty($success_message)): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <form method="post" action="add_course.php">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <label for="course_name">Course Name:</label><br>
            <input type="text" id="course_name" name="course_name" required><br><br>

            <label for="teacher_id">Assign to Teacher:</label><br>
            <select id="teacher_id" name="teacher_id" required>
                <option value="">Select a Teacher</option>
                <?php foreach ($teachers as $teacher): ?>
                    <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['username']); ?></option>
                <?php endforeach; ?>
            </select><br><br>

            <button type="submit">Add Course</button>
        </form>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
