<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'admin') {
    header('Location: ../home/index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['user_id'], $_POST['course_id'], $_POST['attendance_date'], $_POST['status'])) {
        $user_id = $_POST['user_id'];
        $course_id = $_POST['course_id'];
        $attendance_date = $_POST['attendance_date'];
        $status = $_POST['status'];

        $stmt = $conn->prepare("UPDATE attendance SET status = ? WHERE student_id = ? AND course_id = ? AND attendance_date = ?");
        $stmt->bind_param('siis', $status, $user_id, $course_id, $attendance_date);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Attendance updated successfully.";
            header("Location: view_update attendance.php?attendance_updated=true");
            exit();
        } else {
            $_SESSION['message'] = "Failed to update attendance: " . $stmt->error;
            header("Location: view_attendance.php?attendance_updated=false");
            exit();
        }
        $stmt->close();
    }
} else {
    header("Location: view_update attendance.php");
    exit();
}
?>
