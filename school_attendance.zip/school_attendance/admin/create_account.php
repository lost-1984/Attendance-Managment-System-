<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../home/index.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <title>Create Account</title>
</head>
<body>
    <div class="container">
        <h2>Create Account</h2>
        <ul>
            <li><a href="../teacher/register_teacher.php">Register as Teacher</a></li>
            <li><a href="../student/register_student.php">Register as Student</a></li>
        </ul>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
    <script src="../assets/js/admin.js"></script>
</body>
</html>
