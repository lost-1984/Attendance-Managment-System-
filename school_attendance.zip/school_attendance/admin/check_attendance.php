<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'admin') {
    header('Location: ../home/index.php');
    exit();
}

$admin_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    $course_id = $_POST['course_id'];

    $stmt = $conn->prepare("
        SELECT s.id, s.username,
            SUM(a.status = 'present') AS total_present,
            SUM(a.status = 'absent') AS total_absent,
            COUNT(*) AS total_classes
        FROM users s
        JOIN attendance a ON s.id = a.student_id
        WHERE a.course_id = ?
        GROUP BY s.id, s.username
    ");
    $stmt->bind_param('i', $course_id);
    $stmt->execute();
    $students_result = $stmt->get_result();
    $students = $students_result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    $students = [];
}

$stmt = $conn->prepare("SELECT id, course_name FROM courses");
$stmt->execute();
$courses_result = $stmt->get_result();
$courses = [];
while ($row = $courses_result->fetch_assoc()) {
    $courses[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <title>Check Student Attendance</title>
    <style>
        .container {
            width: 80%;
            margin: 50px auto;
            text-align: center;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .table-container {
            max-height: 150px;
            overflow-y: auto;
            position: relative;
        }
        .table-container table {
            width: 100%;
        }
        .table-container thead th {
            position: sticky;
            top: 0;
            background: #f9f9f9;
        }
        select{
            padding: 10px;
            margin-top: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Check Student Attendance</h1>
        <form method="POST" action="check_attendance.php">
            <label for="course_id">Select Course:</label>
            <select id="course_id" name="course_id" required>
                <option value="">Select a Course</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['course_name']); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">View Attendance</button>
        </form>

        <?php if (!empty($students)): ?>
            <h2>Attendance Records</h2>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Total Present</th>
                            <th>Total Absent</th>
                            <th>Attendance Percentage</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <?php
                                $attendance_percentage = $student['total_classes'] > 0 ? ($student['total_present'] / $student['total_classes']) * 100 : 0;
                            ?>
                            <tr>
                                <td><?php echo $student['id']; ?></td>
                                <td><?php echo htmlspecialchars($student['username']); ?></td>
                                <td><?php echo $student['total_present']; ?></td>
                                <td><?php echo $student['total_absent']; ?></td>
                                <td><?php echo number_format($attendance_percentage, 2); ?>%</td>
                                <td>
                                    <form method="GET" action="student_attendance_details.php">
                                        <input type="hidden" name="student_id" value="<?php echo $student['id']; ?>">
                                        <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
                                        <button type="submit">Details</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <p>No students found for the selected course.</p>
        <?php endif; ?>

        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
