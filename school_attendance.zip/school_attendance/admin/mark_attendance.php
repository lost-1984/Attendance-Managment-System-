<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'admin') {
    header('Location: ../home/index.php');
    exit();
}

$error_message = "";
$success_message = "";

$courses_result = $conn->query("SELECT id, course_name FROM courses");
$courses = $courses_result->fetch_all(MYSQLI_ASSOC);

$students = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    $selected_course_id = $_POST['course_id'];
    $students_stmt = $conn->prepare("
        SELECT u.id, u.username 
        FROM users u
        JOIN student_courses sc ON u.id = sc.student_id
        WHERE sc.course_id = ?
    ");
    $students_stmt->bind_param('i', $selected_course_id);
    $students_stmt->execute();
    $students_result = $students_stmt->get_result();
    $students = $students_result->fetch_all(MYSQLI_ASSOC);
    $students_stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id']) && isset($_POST['course_id']) && isset($_POST['status']) && isset($_POST['attendance_date'])) {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course_id'];
    $status = $_POST['status'];
    $date = $_POST['attendance_date'];

    try {
        $stmt = $conn->prepare("INSERT INTO attendance (student_id, course_id, attendance_date, status) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('iiss', $student_id, $course_id, $date, $status);
        $stmt->execute();
        $stmt->close();
        $success_message = "Attendance marked successfully.";
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) { 
            $error_message = "Attendance for this student in this course has already been marked for the selected date.";
        } else {
            $error_message = " ";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../assets/css/admin.css">
    <title>Mark Attendance</title>
    <style>
        .container {
            width: 80%;
            margin: auto;
            padding-top: 20px;
        }
        label {
            display: block;
            margin-top: 10px;
        }
        select, input[type="text"], input[type="number"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 20px;
        }
        button:hover {
            background-color: #45a049;
        }
        .error-message {
            color: red;
            margin-top: 20px;
        }
        .success-message {
            color: green;
            margin-top: 20px;
        }
        label[for="attendance_date"] {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="date"]:focus {
            outline: none;
            border-color: #007bff;
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>Mark Attendance</h1>
        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php elseif (!empty($success_message)): ?>
            <div class="success-message"><?php echo htmlspecialchars($success_message); ?></div>
        <?php elseif (isset($_POST['course_id']) && empty($students)): ?>
            <div class="error-message">No students registered in this course.</div>
        <?php endif; ?>
        <form method="post" action="">
            <label for="course_id">Select Course:</label>
            <select id="course_id" name="course_id" required onchange="this.form.submit()">
                <option value="">Select a Course</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['id']; ?>" <?php if(isset($selected_course_id) && $selected_course_id == $course['id']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($course['course_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <?php if (!empty($students)): ?>
                <label for="student_id">Select Student:</label>
                <select id="student_id" name="student_id" required>
                    <option value="">Select a Student</option>
                    <?php foreach ($students as $student): ?>
                        <option value="<?php echo $student['id']; ?>"><?php echo htmlspecialchars($student['username'] . ' (ID: ' . $student['id'] . ')'); ?></option>
                    <?php endforeach; ?>
                </select>
                
                <label for="status">Status:</label>
                <select id="status" name="status" required>
                    <option value="present">Present</option>
                    <option value="absent">Absent</option>
                </select>

                <label for="attendance_date">Attendance Date:</label>
                <input type="date" id="attendance_date" name="attendance_date" max="<?php echo date('Y-m-d'); ?>" required>

                <button type="submit">Mark Attendance</button>
            <?php endif; ?>
        </form>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
    <script src="../assets/js/admin.js"></script>
</body>
</html>
