<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../home/index.php');
    exit();
}

include('../includes/db_connect.php');

$stmt = $conn->prepare("
    SELECT c.course_name, u.username AS teacher_name
    FROM courses c
    JOIN users u ON c.teacher_id = u.id
");
$stmt->execute();
$courses_result = $stmt->get_result();
$courses = $courses_result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$courses_by_teacher = [];
foreach ($courses as $course) {
    $teacher = $course['teacher_name'];
    if (!isset($courses_by_teacher[$teacher])) {
        $courses_by_teacher[$teacher] = [];
    }
    $courses_by_teacher[$teacher][] = $course['course_name'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="admin.css">
    <style>
        .container {
            width: 80%;
            margin: auto;
            padding-top: 20px;
        }
        
        h1, h2 {
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border: 2px solid black;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    <title>Courses by Teacher</title>
</head>
<body>
    <div class="container">
        <h1>Courses Offered and Taught by Teachers</h1>
        <?php foreach ($courses_by_teacher as $teacher => $courses): ?>
            <h2><?php echo htmlspecialchars($teacher); ?></h2>
            <table>
                <tr>
                    <th>Course Name</th>
                </tr>
                <?php foreach ($courses as $course): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($course); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table><hr>
        <?php endforeach; ?>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
