document.addEventListener('DOMContentLoaded', function() {
    console.log('Teacher JS loaded.');
});
