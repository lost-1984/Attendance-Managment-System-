document.addEventListener('DOMContentLoaded', function() {
    console.log('Admin JS loaded.');
});
