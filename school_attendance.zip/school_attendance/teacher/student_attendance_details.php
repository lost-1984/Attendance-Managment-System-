<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'teacher') {
    header('Location: ../home/index.php');
    exit();
}

if (!isset($_GET['student_id']) || !isset($_GET['course_id'])) {
    header('Location: check_attendance.php');
    exit();
}

$student_id = $_GET['student_id'];
$course_id = $_GET['course_id'];

$stmt = $conn->prepare("
    SELECT attendance_date, status 
    FROM attendance 
    WHERE student_id = ? AND course_id = ?
");
$stmt->bind_param('ii', $student_id, $course_id);
$stmt->execute();
$attendance_result = $stmt->get_result();
$attendance_records = $attendance_result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param('i', $student_id);
$stmt->execute();
$stmt->bind_result($student_username);
$stmt->fetch();
$stmt->close();

$stmt = $conn->prepare("SELECT course_name FROM courses WHERE id = ?");
$stmt->bind_param('i', $course_id);
$stmt->execute();
$stmt->bind_result($course_name);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="teacher.css">
    <title>Student Attendance Details</title>
    <style>
        .container {
            width: 80%;
            margin: 50px auto;
            text-align: center;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .table-container {
            max-height: 400px;
            overflow-y: auto;
            position: relative;
        }
        .table-container table {
            width: 100%;
        }
        .table-container thead th {
            position: sticky;
            top: 0;
            background: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Attendance Details for <?php echo htmlspecialchars($student_username); ?></h1>
        <h2>Course: <?php echo htmlspecialchars($course_name); ?></h2>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance_records as $record): ?>
                        <tr>
                            <td><?php echo $record['attendance_date']; ?></td>
                            <td><?php echo $record['status']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <a href="check_attendance.php">Back to Check Attendance</a>
    </div>
</body>
</html>
