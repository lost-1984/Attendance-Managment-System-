<?php
session_start();
if ($_SESSION['role'] !== 'teacher') {
    header('Location: ../home/index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['course']) && is_array($_POST['course'])) {
        foreach ($_POST['course'] as $course_id) {
            echo "Selected Course ID: $course_id<br>";
        }
    } else {
        echo "No courses selected!";
    }
} else {
    echo "Form not submitted!";
}
?>
