<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'teacher') {
    header('Location: ../home/index.php');
    exit();
}

$teacher_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id, course_name FROM courses WHERE teacher_id = ?");
$stmt->bind_param('i', $teacher_id);
$stmt->execute();
$courses_result = $stmt->get_result();
$courses = [];
while ($row = $courses_result->fetch_assoc()) {
    $courses[] = $row;
}
$stmt->close();

$success_message = "";
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'])) {
    if (isset($_POST['student_ids']) && is_array($_POST['student_ids'])) {
        $course_id = $_POST['course_id'];
        $attendance_date = $_POST['attendance_date'];

        foreach ($_POST['student_ids'] as $student_id) {
            $status = $_POST['status'][$student_id];

            $stmt = $conn->prepare("INSERT INTO attendance (student_id, course_id, attendance_date, status) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE status = VALUES(status)");
            $stmt->bind_param('iiss', $student_id, $course_id, $attendance_date, $status);
            $stmt->execute();
        }
        $stmt->close();
        $success_message = "Attendance marked successfully.";
    } else {
        $error_message = "No students registered for this course.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="teacher.css">
    <title>Mark Attendance</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        label[for="attendance_date"] {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }

        input[type="date"] {
            width: 20%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="date"]:focus {
            outline: none;
            border-color: #007bff;
        }
    </style>
    <script>
        $(document).ready(function() {
            $('#course_id').change(function() {
                var course_id = $(this).val();
                $.ajax({
                    url: 'get_students.php',
                    type: 'GET',
                    data: { course_id: course_id },
                    success: function(response) {
                        $('#students').html(response);
                    }
                });
            });

            $('#attendance_date').change(function() {
                var selectedDate = $(this).val();
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <h1>Mark Attendance</h1>
        <?php if ($success_message): ?>
            <div class="success-message"><?php echo $success_message; ?></div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form method="post" action="">
            <label for="course_id">Course:</label>
            <select id="course_id" name="course_id" required>
                <option value="">Select a course</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['id']; ?>"><?php echo $course['course_name']; ?></option>
                <?php endforeach; ?>
            </select>

            <label for="attendance_date">Attendance Date:</label>
            <input type="date" id="attendance_date" name="attendance_date" required>

            <div id="students"></div>

            <button type="submit">Mark Attendance</button>
        </form>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
    <script src="../assets/js/teacher.js"></script>
</body>
</html>
