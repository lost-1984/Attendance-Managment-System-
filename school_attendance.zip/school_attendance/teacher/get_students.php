<?php
include('../includes/db_connect.php');

if (isset($_GET['course_id'])) {
    $course_id = $_GET['course_id'];

    $stmt = $conn->prepare("
        SELECT u.id, u.username 
        FROM users u
        JOIN student_courses sc ON u.id = sc.student_id
        WHERE sc.course_id = ?
    ");
    $stmt->bind_param('i', $course_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    echo '<div id="students">';
    while ($row = $result->fetch_assoc()) {
        echo '<div class="student-row">';
        echo '<label class="student-name"> <b>' . $row['username'] . ' </b> </label>';
        echo '<input type="hidden" name="student_ids[]" value="' . $row['id'] . '">';
        echo '<div class="attendance-options">';
        echo '<label><input type="radio" name="status[' . $row['id'] . ']" value="present" required> Present</label>';
        echo '<label><input type="radio" name="status[' . $row['id'] . ']" value="absent" required> Absent</label> <hr>';
        echo '</div>'; // .attendance-options
        echo '</div>'; // .student-row
    }
    echo '</div>'; // #students
    $stmt->close();
}
?>
