<?php
session_start();
include('../includes/db_connect.php');

$attendance_updated = isset($_GET['attendance_updated']) && $_GET['attendance_updated'] === 'true';

if ($_SESSION['role'] !== 'teacher') {
    header('Location: ../home/index.php');
    exit();
}

$teacher_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param('i', $teacher_id);
$stmt->execute();
$stmt->bind_result($teacher_username);
$stmt->fetch();
$stmt->close();

$stmt = $conn->prepare("SELECT id, course_name FROM courses WHERE teacher_id = ?");
$stmt->bind_param('i', $teacher_id);
$stmt->execute();
$courses_result = $stmt->get_result();
$courses = [];
while ($row = $courses_result->fetch_assoc()) {
    $courses[] = $row;
}
$stmt->close();

$students = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['course_id'], $_POST['attendance_date'])) {
    $course_id = $_POST['course_id'];
    $attendance_date = $_POST['attendance_date'];

    $stmt = $conn->prepare("SELECT course_name FROM courses WHERE id = ?");
    $stmt->bind_param('i', $course_id);
    $stmt->execute();
    $stmt->bind_result($course_name);
    $stmt->fetch();
    $stmt->close();

    $stmt = $conn->prepare("
        SELECT u.id AS user_id, u.username, a.attendance_date, a.status
        FROM users u
        LEFT JOIN student_courses sc ON u.id = sc.student_id
        LEFT JOIN attendance a ON u.id = a.student_id AND a.course_id = ? AND a.attendance_date = ?
        WHERE u.role = 'student' AND sc.course_id = ?
    ");
    $stmt->bind_param('iss', $course_id, $attendance_date, $course_id);
    $stmt->execute();
    $students_result = $stmt->get_result();
    while ($row = $students_result->fetch_assoc()) {
        $students[] = $row;
    }
    $stmt->close();
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>View Attendance</title>
    <link rel="stylesheet" type="text/css" href="teacher.css">
    <style>
        .container {
            width: 80%;
            margin: 50px auto;
            text-align: center;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        form {
            margin: 20px auto;
            width: 50%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        label {
            margin-bottom: 10px;
            font-weight: bold;
        }

        select,
        input[type="date"],
        button {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .error-message {
            color: red;
            font-weight: bold;
            display: none;
        }
    </style>
    <script>
        function validateForm(form) {
            const radios = form.querySelectorAll('input[type="radio"]');
            let radioChecked = false;
            for (let radio of radios) {
                if (radio.checked) {
                    radioChecked = true;
                    break;
                }
            }
            if (!radioChecked) {
                const errorMessage = form.querySelector('.error-message');
                errorMessage.style.display = 'block';
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>View Attendance</h1>
        <?php
            if (isset($_SESSION['message'])) {
                echo "<p>{$_SESSION['message']}</p>";
                unset($_SESSION['message']);
            }
        ?>
        
        <form method="post" action="view_attendance.php">
            <label for="course_id">Select Course:</label>
            <select id="course_id" name="course_id" required>
                <option value="">Select Course</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['course_name']); ?></option>
                <?php endforeach; ?>
            </select>
            <label for="attendance_date">Select Date:</label>
            <input type="date" id="attendance_date" name="attendance_date" required>
            <button type="submit">View Attendance</button>
        </form>

        <h2>Selected Course:</h2>
        <p><?php echo isset($course_name) ? $course_name : 'No course selected'; ?></p>

        <h2>Students for Selected Course:</h2>
        <?php if (!empty($students)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Student ID</th>
                        <th>Student Name</th>
                        <th>Attendance Date</th>
                        <th>Attendance Status</th> <!-- New column -->
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><?php echo $student['user_id']; ?></td>
                            <td><?php echo htmlspecialchars($student['username']); ?></td>
                            <td><?php echo $student['attendance_date'] ?? ''; ?></td>
                            <td><?php echo ucfirst($student['status']); ?></td>
                            <td>
                                <form method="post" action="update_attendance.php" onsubmit="return validateForm(this)">
                                    <input type="hidden" name="user_id" value="<?php echo $student['user_id']; ?>">
                                    <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
                                    <input type="hidden" name="attendance_date" value="<?php echo $attendance_date; ?>">

                                    <?php if ($student['status'] === 'present'): ?>
                                        <input type="radio" name="status" value="absent"> Absent
                                    <?php elseif ($student['status'] === 'absent'): ?>
                                        <input type="radio" name="status" value="present"> Present
                                    <?php endif; ?>

                                    <div class="error-message">Please select an attendance status.</div>
                                    <button type="submit">Update</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No students found for the selected course and date.</p>
        <?php endif; ?>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
