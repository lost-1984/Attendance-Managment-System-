<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'teacher') {
    header('Location: ../home/index.php');
    exit();
}

$teacher_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param('i', $teacher_id);
$stmt->execute();
$stmt->bind_result($teacher_username);
$stmt->fetch();
$stmt->close();

$stmt = $conn->prepare("SELECT id, course_name FROM courses WHERE teacher_id = ?");
$stmt->bind_param('i', $teacher_id);
$stmt->execute();
$courses_result = $stmt->get_result();
$courses = [];
while ($row = $courses_result->fetch_assoc()) {
    $courses[] = $row;
}
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = $_POST['course_id'];

    $stmt = $conn->prepare("UPDATE courses SET teacher_id = NULL WHERE id = ?");
    $stmt->bind_param('i', $course_id);
    $stmt->execute();
    $stmt->close();

    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="teacher.css">
    <title>Teacher Dashboard</title>
    <style>
        .container {
            width: 80%;
            margin: 50px auto;
            text-align: center;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        button {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #d32f2f;
        }
        .greeting {
            font-size: 20px;
            font-weight: bold;
            text-align: left;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="greeting">
            Hi, <?php echo htmlspecialchars($teacher_username); ?>
        </div>
        <h1>Welcome Teacher</h1>
        <a href="mark_attendance.php">Mark Attendance</a>
        <a href="view_attendance.php">View/Update Attendance</a>
        <a href="check_attendance.php">Students Attendance Record</a>
        <a href="change_password.php">Change Password</a>
    
        <h2>Assigned Courses</h2>
        <?php if (count($courses) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Course ID</th>
                        <th>Course Name</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $course): ?>
                        <tr>
                            <td><?php echo $course['id']; ?></td>
                            <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No courses registered yet.</p>
        <?php endif; ?>
        <a href="../includes/logout.php">Logout</a>
    </div>
    <script src="../assets/js/teacher.js"></script>
</body>
</html>
