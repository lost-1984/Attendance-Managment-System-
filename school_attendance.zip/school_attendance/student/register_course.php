<?php
session_start();
include('../includes/db_connect.php');
if ($_SESSION['role'] !== 'student') {
    header('Location: ../home/index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = $_POST['course_id'];
    $student_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO student_courses (student_id, course_id) VALUES (?, ?)");
    $stmt->bind_param('ii', $student_id, $course_id);
    $stmt->execute();
    $stmt->close();

    header('Location: dashboard.php');
    exit();
}

$student_id = $_SESSION['user_id'];
$courses = [];
$stmt = $conn->prepare("
    SELECT c.id, c.course_name 
    FROM courses c
    LEFT JOIN student_courses sc ON c.id = sc.course_id AND sc.student_id = ?
    WHERE sc.course_id IS NULL
");
$stmt->bind_param('i', $student_id);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $courses[] = $row;
}
$stmt->close();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../assets/css/student.css">
    <title>Register to Course</title>
</head>
<body>
    <div class="container">
        <h1>Register to Course</h1>
        <form method="post" action="">
            <label for="course_id">Select Course:</label>
            <select id="course_id" name="course_id" required>
                <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['id']; ?>">
                        <?php echo htmlspecialchars($course['course_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Register</button>
        </form>
        <a href="dashboard.php" class="back-to-dashboard">Back to Dashboard</a>
    </div>
    <script src="../assets/js/student.js"></script>
</body>
</html>
