<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'student') {
    header('Location: ../home/index.php');
    exit();
}

$student_id = $_SESSION['user_id'];

if (isset($_SESSION['course_dropped'])) {
    $dropped_course_id = $_SESSION['course_dropped'];
    unset($_SESSION['course_dropped']);

    $stmt = $conn->prepare("DELETE FROM attendance WHERE student_id = ? AND course_id = ?");
    $stmt->bind_param('ii', $student_id, $dropped_course_id);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../assets/css/student.css">
    <title>Check Attendance</title>
    <style>
        .table-container {
            max-height: 150px; 
            overflow-y: auto;
            position: relative;
        }
        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }
        thead th {
            position: sticky;
            top: 0;
            background: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Your Attendance</h1>
        <?php
        $stmt = $conn->prepare("SELECT DISTINCT c.id, c.course_name FROM courses c JOIN student_courses sc ON c.id = sc.course_id WHERE sc.student_id = ?");
        $stmt->bind_param('i', $student_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($course = $result->fetch_assoc()) {
                $course_id = $course['id'];
                echo "<h2>{$course['course_name']}</h2>";

                $stmt2 = $conn->prepare("
                    SELECT 
                        SUM(status = 'present') AS total_present,
                        SUM(status = 'absent') AS total_absent,
                        COUNT(*) AS total_classes
                    FROM attendance 
                    WHERE student_id = ? AND course_id = ?
                ");
                $stmt2->bind_param('ii', $student_id, $course_id);
                $stmt2->execute();
                $attendance_stats_result = $stmt2->get_result();
                $attendance_stats = $attendance_stats_result->fetch_assoc();

                $total_present = $attendance_stats['total_present'];
                $total_absent = $attendance_stats['total_absent'];
                $total_classes = $attendance_stats['total_classes'];
                $attendance_percentage = $total_classes > 0 ? ($total_present / $total_classes) * 100 : 0;

                echo "<p>Total Present: $total_present</p>";
                echo "<p>Total Absent: $total_absent</p>";
                echo "<p>Attendance Percentage: " . number_format($attendance_percentage, 2) . "%</p>";

                echo "<div class='table-container'>
                        <table>
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>";

                $stmt3 = $conn->prepare("
                    SELECT attendance_date, status 
                    FROM attendance 
                    WHERE student_id = ? AND course_id = ?
                ");
                $stmt3->bind_param('ii', $student_id, $course_id);
                $stmt3->execute();
                $attendance_result = $stmt3->get_result();

                while ($attendance = $attendance_result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$attendance['attendance_date']}</td>
                            <td>{$attendance['status']}</td>
                        </tr>";
                }

                $stmt3->close();

                echo "</tbody></table></div><hr>";
            }
        } else {
            echo "<p>You have not registered to any course. <a href='register_course.php'>Register a course</a></p>";
        }

        $stmt->close();
        ?>
        <a href="dashboard.php">Back to Dashboard</a>
    </div>
    <script src="../assets/js/student.js"></script>
</body>
</html>
