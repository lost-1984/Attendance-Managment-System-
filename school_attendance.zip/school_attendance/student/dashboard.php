<?php
session_start();
include('../includes/db_connect.php');

if ($_SESSION['role'] !== 'student') {
    header('Location: ../home/index.php');
    exit();
}

$student_id = $_SESSION['user_id'];
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->bind_param('i', $student_id);
$stmt->execute();
$stmt->bind_result($student_username);
$stmt->fetch();
$stmt->close();

$stmt = $conn->prepare("
    SELECT sc.id AS student_course_id, c.id AS course_id, c.course_name 
    FROM student_courses sc
    JOIN courses c ON sc.course_id = c.id
    WHERE sc.student_id = ?
");
$stmt->bind_param('i', $student_id);
$stmt->execute();
$result = $stmt->get_result();
$courses = [];
while ($row = $result->fetch_assoc()) {
    $courses[] = $row;
}
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_course_id = $_POST['student_course_id'];

    $stmt = $conn->prepare("SELECT course_id FROM student_courses WHERE id = ?");
    $stmt->bind_param('i', $student_course_id);
    $stmt->execute();
    $stmt->bind_result($course_id);
    $stmt->fetch();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM attendance WHERE student_id = ? AND course_id = ?");
    $stmt->bind_param('ii', $student_id, $course_id);
    $stmt->execute();
    $stmt->close();

    $stmt = $conn->prepare("DELETE FROM student_courses WHERE id = ?");
    $stmt->bind_param('i', $student_course_id);
    $stmt->execute();
    $stmt->close();

    header('Location: dashboard.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="student.css">
    <title>Student Dashboard</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        button {
            background-color: #f44336;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #d32f2f;
        }
        .greeting {
            font-size: 20px;
            font-weight: bold;
            text-align: left;
            margin-bottom: 20px;
            text-transform: uppercase;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="greeting">
            Hi, <?php echo htmlspecialchars($student_username); ?>
        </div>
        <h1>Welcome Student</h1>
        <a href="register_course.php">Register to Course</a>
        <a href="check_attendance.php">Check Attendance</a>
        <a href="change_password.php">Change Password</a>
        <h2>Your Registered Courses</h2>
        <?php if (count($courses) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Course ID</th>
                        <th>Course Name</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($courses as $course): ?>
                        <tr>
                            <td><?php echo $course['course_id']; ?></td>
                            <td><?php echo htmlspecialchars($course['course_name']); ?></td>
                            <td>
                                <form method="post" action="">
                                    <input type="hidden" name="student_course_id" value="<?php echo $course['student_course_id']; ?>">
                                    <button type="submit">Drop</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>You are not registered in any courses yet.</p>
        <?php endif; ?>
        <a href="../includes/logout.php">Logout</a>
    </div>
    <script src="../assets/js/student.js"></script>
</body>
</html>
