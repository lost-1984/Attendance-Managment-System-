<?php
header('Location: home/index.php');
exit();
?>
