<?php
function loginUser($username, $password, $role) {
    global $conn;
    $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ? AND role = ?");
    $stmt->bind_param('ss', $username, $role);
    $stmt->execute();
    $stmt->bind_result($id, $db_username, $db_password, $db_role);
    $stmt->fetch();
    
    if (password_verify($password, $db_password)) {
        return [
            'id' => $id,
            'username' => $db_username,
            'role' => $db_role
        ];
    }

    return false;
}
?>
