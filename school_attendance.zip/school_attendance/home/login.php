<?php
include('../includes/db_connect.php');
include('../includes/functions.php');

$role = $_GET['role'] ?? 'student';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $user = loginUser($username, $password, $role);

    if ($user) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role'];
        header('Location: ../' . $user['role'] . '/dashboard.php');
        exit();
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../assets/css/style_login.css">
    <title>Login - <?php echo ucfirst($role); ?></title>
    <style>
        a{
            font-size: 18px;
            text-align: left;
            font-weight: bold;
            display: flex;
            color : black;
            align-items: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="../home/index.php"><img src="home.png" alt="" > Home </a>
        <h1><?php echo ucfirst($role); ?> Login</h1>
        <?php if (isset($error)) { echo "<p>$error</p>"; } ?>
        <form action="" method="post">
            <input type="hidden" name="role" value="<?php echo $role; ?>">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Login</button>
        </form>
    </div>
    <script src="../assets/js/script.js"></script>
</body>
</html>
