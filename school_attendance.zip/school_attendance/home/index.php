<?php include('../includes/header.php'); ?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <title>School Attendance System</title>
</head>
<body>
    <div class="container">
        <h1>Welcome to the School Attendance System</h1>
        <form action="login.php" method="get">
            <label for="role">Select Your Role:</label>
            <select name="role" id="role">
                <option value="student">Student</option>
                <option value="teacher">Teacher</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit">Login</button>
        </form>
        <h2>Create Account</h2>
        <ul>
            <li><a href="../admin/register_admin.php">Register as Admin</a></li>
            <li><a href="../teacher/register_teacher.php">Register as Teacher</a></li>
            <li><a href="../student/register_student.php">Register as Student</a></li>
        </ul>
    </div>
    <script src="../assets/js/script.js"></script>
</body>
</html>
<?php include('../includes/footer.php'); ?>
